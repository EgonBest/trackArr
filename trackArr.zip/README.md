#tracking to Array

